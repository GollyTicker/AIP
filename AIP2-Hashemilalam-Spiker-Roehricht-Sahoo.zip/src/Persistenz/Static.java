package Persistenz;

/**
 * Created by Swaneet on 13.11.2014.
 */
public class Static {
}
